VAIDHU LUXURY PROPOSAL

1. Extract this ZIP.
2. Open the VAIDHU_LUXURY_PROPOSAL folder in VS Code.
3. Open index.html in Chrome or use Live Server.
4. Optional music: put a permitted MP3 named music.mp3 beside index.html.
5. For GitHub Pages, upload index.html, the entire images folder, and music.mp3 if used.
6. Enable Settings > Pages, then test the public URL on a phone.

Mobile note: background music starts only after the visitor taps PLAY MUSIC.
Photo privacy: share these pictures and the published page only with the recipient's consent.
